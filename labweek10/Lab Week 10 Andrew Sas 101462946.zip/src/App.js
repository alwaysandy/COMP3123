import logo from './logo.svg';
import './App.css';
import UserSignupForm from './components/UserSignupForm';

function App() {
  return (
    <div>
      <UserSignupForm />
    </div>
  );
}

export default App;
